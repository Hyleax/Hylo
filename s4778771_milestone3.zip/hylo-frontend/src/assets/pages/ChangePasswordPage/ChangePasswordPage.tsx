import React from 'react'
import ChangePasswordForm from '../../components/FORMS/ChangePasswordForm/ChangePasswordForm'
import './ChangePasswordPage.css'

const ChangePasswordPage = () => {
  return (
    <div className='forget-password-page-container'>
        <ChangePasswordForm/>
    </div>
  )
}

export default ChangePasswordPage