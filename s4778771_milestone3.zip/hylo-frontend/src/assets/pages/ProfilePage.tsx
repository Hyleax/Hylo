import React, {useState, useEffect} from 'react'
import axios from 'axios'
import MainProfile from '../components/PROFILE/MainProfile/MainProfile'

// main profile page
const ProfilePage = () => {

  return (
    <div className='profile-page-container'>
        <MainProfile 
    
        />   
    </div>
  )
}



export default ProfilePage